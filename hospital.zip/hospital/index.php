<?php
$conn = mysqli_connect('localhost','root','','contact_db') or die('connection failed');

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $number = $_POST['number'];
   $date = $_POST['date'];

   $insert = mysqli_query($conn, "INSERT INTO `contact_form`(name, email, number, date) VALUES('$name','$email','$number','$date')") or die('query failed');

   if($insert){
      $message[] = 'appointment made successfully!';
   }else{
      $message[] = 'appointment failed';
   }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medicare</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> <strong>Medi</strong>care </a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#about">about</a>
        <a href="services.html">services</a>
        <a href="#doctors">doctors</a>
        <a href="appointment.php">appointment</a>
        <a href="#review">review</a>
        <a href="#blogs">blogs</a>
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="image">
        <img src="image/home-img.svg" alt="">
    </div>

    <div class="content">
        <h3>"Expert Care, Tailored to You –
Every Moment,Every Day!"</h3>
        <p> Welcome to our Medicare, where your health is our mission. We are dedicated to providing exceptional care tailored to your unique needs, ensuring you feel supported every step of the way. With our expert team and state-of-the-art facilities, we’re committed to helping you heal and thrive.</p>
        <a href="#appointment" class="btn"> appointment us <span class="fas fa-chevron-right"></span> </a>
    </div>

</section>

<!-- home section ends -->

<!-- icons section starts  -->

<section class="icons-container">

    <div class="icons">
        <i class="fas fa-user-md"></i>
        <h3>100+</h3>
        <p>doctors at work</p>
    </div>

    <div class="icons">
        <i class="fas fa-users"></i>
        <h3>2010+</h3>
        <p>satisfied patients</p>
    </div>

    <div class="icons">
        <i class="fas fa-procedures"></i>
        <h3>590+</h3>
        <p>bed facility</p>
    </div>

    <div class="icons">
        <i class="fas fa-hospital"></i>
        <h3>60+</h3>
        <p>available hospitals</p>
    </div>

</section>

<!-- icons section ends -->

<!-- about section starts  -->

<section class="about" id="about">

    <h1 class="heading"> <span>about</span> us </h1>

    <div class="row">

        <div class="image">
            <img src="image/about-img.svg" alt="">
        </div>

        <div class="content">
            <h3>take the world's best quality treatment</h3>
            <p>Welcome to MediCare.Our mission is to deliver exceptional, patient-centered care in a modern, state-of-the-art environment, ensuring that every individual receives the attention and expertise they truly deserve.</p>
            <p>Our dedicated team of healthcare professionals—comprised of experienced doctors, compassionate nurses, and supportive staff—works collaboratively to provide a seamless and uplifting experience for our patients. We offer a comprehensive range of services, from routine check-ups to specialized treatments, harnessing the latest medical technology to achieve the best outcomes for you.</p>
        </div>

    </div>

</section>

<!-- about section ends -->

<!-- services section starts  -->

<section class="services" id="services">

    <h1 class="heading"> our <span>services</span> </h1>

    <div class="box-container">

        <div class="box">
            <i class="fas fa-notes-medical"></i>
            <h3>free checkups</h3>
            <p>At Medicare, we’re making health a priority for everyone with our free check-up services! Enjoy a comprehensive assessment that includes vital health measurements and personalized consultations from our expert team.Let us help you take charge of your health—schedule your free check-up today!</p>
        </div>

        <div class="box">
            <i class="fas fa-ambulance"></i>
            <h3>24/7 ambulance</h3>
            <p>At MediCare, we understand that emergencies can happen at any time, which is why we offer a reliable 24/7 ambulance service to ensure you receive prompt medical attention when you need it most. Our fleet of well-equipped ambulances is staffed by highly trained professionals ready to respond to emergencies swiftly and efficiently.</p>
        </div>

        <div class="box">
            <i class="fas fa-user-md"></i>
            <h3>expert doctors</h3>
            <p>At Medicare, our team of expert doctors is dedicated to providing you with the highest quality of medical care. Each physician is highly trained and experienced in their respective fields, ensuring that you receive personalized and effective treatment tailored to your unique health needs.</p>
        </div>

        <div class="box">
            <i class="fas fa-pills"></i>
            <h3>medicines</h3>
            <p>At Medicare, we understand that effective treatment begins with high-quality medicines. Our commitment to patient care extends beyond diagnosis and treatment; we ensure that our pharmacy offers a comprehensive range of medications to support your health and recovery.</p>
        </div>

        <div class="box">
            <i class="fas fa-procedures"></i>
            <h3>bed facility</h3>
            <p>At Medicare, we prioritize your comfort and well-being during your stay. Our modern bed facilities are designed to provide a soothing and supportive environment that promotes healing and recovery.Each patient room is equipped with state-of-the-art hospital beds that can be easily adjusted for your comfort. Our beds are designed to cater to your specific medical needs, ensuring you have the proper support throughout your recovery. </p>
        </div>

        <div class="box">
            <i class="fas fa-heartbeat"></i>
            <h3>total care</h3>
            <p>At Medicare, we believe in the power of total care—a holistic approach to health and well-being that addresses not just your medical needs but also your emotional and social well-being. Our commitment to total care means that you receive comprehensive support throughout your healthcare journey, from prevention and diagnosis to treatment and recovery.</p>
        </div>

    </div>

</section>

<!-- services section ends -->



<!-- doctors section starts  -->

<section class="doctors" id="doctors">

    <h1 class="heading"> our <span>doctors</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/doc-1.jpg" alt="">
            <h3>Maria</h3>
            <span>General physician</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
                
            </div>
        </div>

        <div class="box">
            <img src="image/doc-2.jpg" alt="">
            <h3>Devis barck</h3>
            <span>Cardiologist</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-3.jpg" alt="">
            <h3>Emmy john</h3>
            <span>Gynaecologist</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-4.jpg" alt="">
            <h3>Sara william</h3>
            <span>Neurologist</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-5.jpg" alt="">
            <h3>David johnson</h3>
            <span>Endocrinologist</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-6.jpg" alt="">
            <h3>Jack tom</h3>
            <span>Orthopedic Surgeon</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            
            </div>
        </div>
        <div class="box">
            <img src="image/doc-7.jpg" alt="">
            <h3>Anne John</h3>
            <span>Paediatrics</span>
            <div class="share">
                
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>
        <div class="box">
            <img src="image/doc-8.jpg" alt="">
            <h3>James</h3>
            <span>Radiologist</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>
        <div class="box">
            <img src="image/doc-9.jpg" alt="">
            <h3>Jacob Thomas</h3>
            <span>Laparoscopic and General Surgeon</span>
            <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

    </div>

</section>

<!-- doctors section ends -->

<!-- review section starts  -->

<section class="review" id="review">
    
    <h1 class="heading"> client's <span>review</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/pic-1.png" alt="">
            <h3>Sebastian</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">"From the moment I arrived, the staff at MediCare made me feel welcome and cared for. The medical team took the time to listen to my concerns and worked diligently to provide me with the best treatment. I felt supported every step of the way!"</p>
        </div>

        <div class="box">
            <img src="image/pic-1.png" alt="">
            <h3>Michael</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">"I had a wonderful experience at MediCare. The facility is clean and well-organized, and the staff is incredibly compassionate. My doctor explained every procedure in detail, which made me feel at ease. I highly recommend this hospital for anyone seeking quality care!"</p>
        </div>

        <div class="box">
            <img src="image/pic-1.png" alt="">
            <h3>William</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">"My experience with MediCare was outstanding! The staff went above and beyond to ensure my comfort and understanding throughout my treatment. I truly felt like a valued patient, not just a number. I will definitely return for any future healthcare needs!"</p>
        </div>

    </div>

</section>

<!-- review section ends -->

<!-- blogs section starts  -->

<section class="blogs" id="blogs">

    <h1 class="heading"> our <span>blogs</span> </h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="image/blog.png" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 21 October, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Dr.Sarah,Gynaecologist </a>
                </div>
                <h3>Laparoscopic Vs Robotic Surgery: Pain Management & Recovery</h3>
                <p>Postoperative recovery is a critical aspect of surgical outcomes, influencing patient comfort, hospital stay duration, and overall satisfaction. Both laparoscopic and robotic-assisted surgeries are minimally invasive techniques that aim to reduce recovery times compared to traditional open surgery. However, there are notable differences in recovery experiences between the two approaches.</p>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="image/blog-2.png" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 11 October, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Dr Henry,Rheumatologist </a>
                </div>
                <h3>World Arthritis Day 2024: Awareness About Rheumatic Disease</h3>
                <p>Every year, World Arthritis Day (WAD) is celebrated on October 12th to increase awareness about rheumatic disease. It was first started by Arthritis and Rheumatism International in 1996.There are more than 100 types of different arthritis that have been described.Although inflammatory arthritis is less than 1–3% among them, the burden of disease is significant.  </p>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="image/blog-3.png" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 24 Sep, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Dr.Jessica,Gynaecologist </a>
                </div>
                <h3>How Menopause Impacts Women's Health and Ageing Process</h3>
                <p>Menopause is an important turning point in a woman’s life. It typically occurs between the ages of 45 and 55 and is defined by the cessation of menstrual cycles for 12 consecutive months. It marks the end of her reproductive years. Menopause is a natural biological process and has profound effects on a woman’s health and ageing, influencing not only physical health but also mental and emotional well-being. </p>   
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="image/blog-4.png" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 14 April, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Dr.Benson,Surgical Oncologist </a>
                </div>
                <h3>Pancreatic Cancer: Causes, Treatment and Prevention Strategies</h3>
                <p>Pancreatic cancer is a serious condition that begins in the tissues of the pancreas, an organ located in the lower part of the stomach, which produces digestive enzymes and hormones such as insulin, playing a vital role in digestion and blood sugar regulation. When cancer develops in this organ, it can have profound effects on the body's overall health and function. Despite being a relatively rare type of cancer, its aggressive nature and high mortality rate make it extremely important for those affected by it to know about the disorder and the way forward. </p>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="image/blog-5.png" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 10 Feb, 2024</a>
                    <a href="#"> <i class="fas fa-user"></i> by Dr.Alexander</a>
                </div>
                <h3>Boost Your Haemoglobin Levels Naturally with these Powerhouse Foods</h3>
                <p>Incorporating these powerhouse foods into your diet is a great step towards boosting your haemoglobin levels naturally and improving your overall health. However, if you are experiencing persistent symptoms of low haemoglobin or have underlying health conditions, it is essential to seek professional medical advice. Consulting with a specialist can provide you with a personalised treatment plan and ensure that you are addressing any underlying issues effectively. </p>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="image/blog-6.png" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 1 Jan, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Jia Thomas,cardiologist </a>
                </div>
                <h3>Atherosclerosis Unravelled: Symptoms, Causes, Treatment and Prevention</h3>
                <p>Atherosclerosis, a common cardiovascular condition, silently affects millions worldwide, altering the course of health without immediate notice. Its insidious nature lies in its ability to develop quietly over time, often without overt symptoms until complications arise, making it essential for affected individuals and their loved ones to understand its complexities. In this article, we delve into the intricacies of Atherosclerosis, covering its symptoms, causes, diagnosis, treatment options, and prevention tips.</p>
            </div>
        </div>

    </div>

</section>

<!-- blogs section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="#home"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="#about"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="#services"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="#doctors"> <i class="fas fa-chevron-right"></i> doctors </a>
            <a href="#appointment"> <i class="fas fa-chevron-right"></i> appointment </a>
            <a href="#review"> <i class="fas fa-chevron-right"></i> review </a>
            <a href="#blogs"> <i class="fas fa-chevron-right"></i> blogs </a>
        </div>

        <div class="box">
            <h3>our services</h3>
            <a href="#"> <i class="fas fa-chevron-right"></i> dental care </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> message therapy </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> cardioloty </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> diagnosis </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> ambulance service </a>
        </div>

        <div class="box">
            <h3>appointment info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +8801688238801 </a>
            <a href="#"> <i class="fas fa-phone"></i> +8801782546978 </a>
            <a href="#"> <i class="fas fa-envelope"></i> medicare@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> sujoncse26@gmail.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> Toronto,Canada </a>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="#"> <i class="fab fa-faceappointment-f"></i> faceappointment </a>
            <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
            <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
            <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
            <a href="#"> <i class="fab fa-pinterest"></i> pinterest </a>
        </div>

    </div>

    <div class="credit"> created by <span>Medicare</span> | all rights reserved </div>

</section>

<!-- footer section ends -->


<!-- js file link  -->
<script src="js/script.js"></script>

</body>
</html>