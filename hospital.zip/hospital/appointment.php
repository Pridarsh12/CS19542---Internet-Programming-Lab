<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment | Medicare</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
<!-- header section starts  -->
<header class="header">
    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> <strong>Medi</strong>care </a>
    <nav class="navbar">
        <a href="index.php#home">home</a>
        <a href="index.php#about">about</a>
        <a href="index.php#services">services</a>
        <a href="index.php#doctors">doctors</a>
        <a href="appointment.php">appointment</a>
        <a href="index.php#review">review</a>
        <a href="index.php#blogs">blogs</a>
    </nav>
    <div id="menu-btn" class="fas fa-bars"></div>
</header>
<!-- header section ends -->

<!-- appointment section starts  -->
<section class="appointment" id="appointment">
    <h1 class="heading"> <span>appointment</span> now </h1>
    <div class="row">
        <div class="image">
            <img src="image/appointment-img.svg" alt="">
        </div>
        <form action="appointment.php" method="post">
            <?php
            if(isset($_POST['submit'])) {
                $name = $_POST['name'];
                $number = $_POST['number'];
                $email = $_POST['email'];
                $date = $_POST['date'];

                // Simple form validation example
                if(empty($name) || empty($number) || empty($email) || empty($date)) {
                    echo '<p class="message">All fields are required!</p>';
                } else {
                    echo '<p class="message">Appointment made successfully!</p>';
                }
            }
            ?>
            <h3>make appointment</h3>
            <input type="text" name="name" placeholder="your name" class="box">
            <input type="number" name="number" placeholder="your number" class="box">
            <input type="email" name="email" placeholder="your email" class="box">
            <input type="date" name="date" class="box">
            <input type="submit" name="submit" value="appointment now" class="btn">
        </form>
    </div>
</section>
<!-- appointment section ends -->

</body>
</html>
